// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:qr_flutter/qr_flutter.dart';

class Qrcode extends StatefulWidget {
  const Qrcode({
    Key? key,
    this.width,
    this.height,
  }) : super(key: key);

  final double? width;
  final double? height;

  @override
  _QrcodeState createState() => _QrcodeState();
}

class _QrcodeState extends State<Qrcode> {
  TextEditingController qrCodeController = TextEditingController();
  String qrdata = '';

  @override
  void dispose() {
    qrCodeController.dispose();
    super.dispose();
  }

  void generateQrCode() {
    setState(() {
      qrdata = qrCodeController.text;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          TextFormField(
            controller: qrCodeController,
            decoration: InputDecoration(
                hintText: 'Enter your text',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20))),
          ),
          const SizedBox(
            height: 50,
          ),
          QrImageView(
            data: qrdata,
            version: QrVersion.auto,
            size: 200.0,
          ),
          SizedBox(
            height: 40,
          ),
          Container(
            width: 160,
            height: 45,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.green,
            ),
            child: MaterialButton(
                onPressed: generateQrCode, child: Text("Create Qr Code")),
          )
        ],
      ),
    );
  }
}

class QrVersion {
  static var auto;
}
