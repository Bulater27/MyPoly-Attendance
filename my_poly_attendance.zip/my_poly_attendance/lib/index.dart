// Export pages
export '/pages/splash_screen/splash_screen_widget.dart' show SplashScreenWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/student_attendance/student_attendance_widget.dart'
    show StudentAttendanceWidget;
export '/pages/register/register_widget.dart' show RegisterWidget;
export '/pages/scanhistory/scanhistory_widget.dart' show ScanhistoryWidget;
export '/pages/edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export '/pages/notification/notification_widget.dart' show NotificationWidget;
export '/pages/my_profile/my_profile_widget.dart' show MyProfileWidget;
export '/pages/change_password/change_password_widget.dart'
    show ChangePasswordWidget;
export '/pages/success/success_widget.dart' show SuccessWidget;
export '/pages/unsuccess/unsuccess_widget.dart' show UnsuccessWidget;
export '/pages/verify/verify_widget.dart' show VerifyWidget;
export '/pages/qrgenerate/qrgenerate_widget.dart' show QrgenerateWidget;
