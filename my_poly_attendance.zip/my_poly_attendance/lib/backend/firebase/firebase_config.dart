import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCzVG8qm-57W5_JsHYyQtE3t3jtlqIgYa4",
            authDomain: "mypolylect.firebaseapp.com",
            projectId: "mypolylect",
            storageBucket: "mypolylect.appspot.com",
            messagingSenderId: "486853553748",
            appId: "1:486853553748:web:73312bd81a943b8cd787c1",
            measurementId: "G-213T8C4FBR"));
  } else {
    await Firebase.initializeApp();
  }
}
